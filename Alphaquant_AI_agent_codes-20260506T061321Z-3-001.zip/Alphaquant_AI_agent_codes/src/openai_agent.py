import os
import json
from openai import OpenAI
from src.agent_toolset import QuantTradingToolset


SYSTEM_PROMPT = """
You are AlphaQuant, a professional AI agent specialising in quantitative trading
strategy analysis. You are deployed on the Nasiko A2A gateway.

Your capabilities:
  1. explain_strategy   – Explain the Impulse Flow Alpha trading strategy clearly.
  2. analyze_performance – Interpret backtest metrics (return, Sharpe, drawdown, etc.).
  3. evaluate_risk      – Summarise stress tests and forward-looking risks.
  4. generate_signal    – Run the signal engine on provided OHLC data.

Response guidelines:
  - Always reply in a clear, structured format.
  - Be precise, analytical, and professional.
  - Do NOT hype unrealistic returns; always mention risks and limitations.
  - If the user provides OHLC data (as JSON or CSV text), extract it and call
    generate_signal automatically.
  - Keep outputs deterministic and consistent for the same input.
  - If a request is outside your four capabilities, politely say so and suggest
    which capability is closest.
"""


class OpenAIAgent:
    """
    Wraps the OpenAI chat API with tool routing via QuantTradingToolset.
    Falls back to a pure LLM response when no tool matches.
    """

    def __init__(self):
        self.client  = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.toolset = QuantTradingToolset()

    # ── Intent detection ──────────────────────────────────────────────────────
    @staticmethod
    def _detect_intent(text: str) -> str | None:
        """
        Light keyword-based intent router.
        Returns one of the tool keys or None (→ fallback to LLM).
        """
        t = text.lower()
        if any(k in t for k in ["explain", "how does", "strategy", "what is impulse",
                                 "what is the strategy", "describe"]):
            return "explain_strategy"
        if any(k in t for k in ["performance", "metrics", "sharpe", "sortino",
                                 "calmar", "return", "drawdown", "annualised"]):
            return "analyze_performance"
        if any(k in t for k in ["risk", "stress", "robust", "overfitting",
                                 "monte carlo", "perturbation", "live"]):
            return "evaluate_risk"
        if any(k in t for k in ["signal", "ohlc", "open", "high", "low", "close",
                                 "generate", "predict", "trade now"]):
            return "generate_signal"
        return None

    # ── Main entry point ──────────────────────────────────────────────────────
    async def run(self, user_input: str) -> str:
        """
        Route request to the appropriate tool or fall back to the LLM.

        Args:
            user_input: Raw user message text.

        Returns:
            Response string.
        """
        try:
            intent = self._detect_intent(user_input)
            tools  = self.toolset.get_tools()

            # ── Tool-routed path ──────────────────────────────────────────────
            if intent and intent in tools:
                if intent == "explain_strategy":
                    return await tools["explain_strategy"](strategy_text=user_input)

                if intent == "analyze_performance":
                    return await tools["analyze_performance"]()

                if intent == "evaluate_risk":
                    return await tools["evaluate_risk"]()

                if intent == "generate_signal":
                    # Try to parse JSON OHLC from the message
                    ohlc = self._extract_ohlc(user_input)
                    if ohlc:
                        return await tools["generate_signal"](ohlc_data=ohlc)
                    # No parseable data → ask LLM to handle gracefully
                    return (
                        "To generate a live signal I need OHLC data.\n"
                        "Please provide a JSON array like:\n"
                        '  [{"Date":"2024-01-01","Open":42000,"High":43000,'
                        '"Low":41500,"Close":42800}, ...]\n'
                        "At least 5 bars are required."
                    )

            # ── LLM fallback ──────────────────────────────────────────────────
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user",   "content": user_input},
                ],
                temperature=0.3,
                max_tokens=1024,
            )
            return response.choices[0].message.content

        except Exception as e:
            return f"Error in AlphaQuant agent: {str(e)}"

    # ── Helper: extract OHLC JSON from free text ──────────────────────────────
    @staticmethod
    def _extract_ohlc(text: str) -> list[dict] | None:
        """
        Attempt to parse a JSON array of OHLC dicts embedded in user text.
        Returns the list if successful, else None.
        """
        try:
            start = text.index("[")
            end   = text.rindex("]") + 1
            return json.loads(text[start:end])
        except (ValueError, json.JSONDecodeError):
            return None